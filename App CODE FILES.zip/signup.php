<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			//save to database
			$user_id = random_num(20);
			$query = "insert into users (user_id,user_name,password) values ('$user_id','$user_name','$password')";

			mysqli_query($con, $query);

			header("Location: login.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
</head>
<body>

	<style type="text/css">
	
	#text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 35%;
	}

	#button{

		padding: 10px;
		width: 38%;
		color: white;
		background-color:blue;
		border: none;
	}

	#box{

		background-color: white;
		margin: auto;
		width: 150px;
		padding: 10px;
		boxsizing:border-box;
	}
	div.relative{
		position:relative;
		left:45px;
		top:2px;
	}
	div.a {
  position: relative;
  left:500px;
 
  
  
}
div.b{
  position: relative;
  left:140px;
 
  
  
}

	</style>

	<div id="box">
		
		<form method="post">
			<divclass="relative" style="font-size: 35px;margin: 10px;color: solid black;">Sign Up</div>
			<div class="b"><div class="a" > <p>  Already have an account? <a href="login.php" >Sign In</a> <p></div></div>
			
			<div class="a" > Email</div>

			<div class="a" > <input id="text" type="text" name="user_name"><br><br> </div>
			
			<div class="a"> password</div>
			
			
			<div class="a" > <input id="text" type="password" name="password"><br><br> </div>
			<div  class="a" > Secret</div>
			<div class="a"> <input id="text" type="Secret" name="secret"><br><br></div>

			<div class="a"> <input id="button" type="submit" value="Sign Up"><br><br></div>
			<div class="a" > <p>By clicking the "Sign Up" Button,you are creating an account ,and agreeing to terms of use .<p></div>
			
			
			
			
			
			

			
		</form>
	</div>
</body>
</html>