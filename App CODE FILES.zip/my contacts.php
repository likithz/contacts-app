 
 
 <?php
  
// Username is root
$user = 'root';
$password = ''; 
  
// Database name is gfg
$database = 'login_sample_db'; 
  
// Server is localhost with
// port number 3308
$databaseHost='localhost';
$mysqli = new mysqli($databaseHost, $user, 
                $password, $database);
  
// Checking for connections
if ($mysqli->connect_error) {
    die('Connect Error (' . 
    $mysqli->connect_errno . ') '. 
    $mysqli->connect_error);
}
  
// SQL query to select data from database
$sql = "SELECT * FROM contacts ";
$result = $mysqli->query($sql);
$mysqli->close(); 
?>


<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <title>GFG User Details</title>
    <!-- CSS FOR STYLING THE PAGE -->
    <style>
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px  black;
        }
  
        h1 {
            text-align: center;
            color: black;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT', 
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
  
        td {
            background-color: white;
            border: 1px solid black;
			padding:10px;
        }
  
        th{
			background-color:grey;
			padding:15px;
			color:white;
		}
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
  
        td {
            font-weight: lighter;
        }
    </style>
	
	<h2> <a href="logout.php" >Logout</a> </h2>
</head>
  
<body>
    <section>
        <h1>My Contacts</h1>
	
        <!-- TABLE CONSTRUCTION-->
        <table>
            <tr>
                <th>Name</th>
                <th>Ph No</th>
                <th>Email</th>
                
            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS-->
            <?php   // LOOP TILL END OF DATA 
                while($rows=$result->fetch_assoc())
                {
             ?>
            <tr>
                <!--FETCHING DATA FROM EACH 
                    ROW OF EVERY COLUMN-->
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['phNo'];?></td>
                <td><?php echo $rows['email'];?></td>
                
            </tr>
            <?php
                }
             ?>
			 <div > <h1>  <a href="logout.php" ></a> </h1></div>
        </table>
		
    </section>
	
</body>
  
</html>

 //<?php
{
	//header("Location:logout.php");
}
// ?> 
