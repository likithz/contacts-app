<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$name = $_POST['name'];
		$phNo= $_POST['phNo'];
		$email=$_POST['email'];

		if(!empty($name) && !empty($phNo) && !empty($email) && !is_numeric($email) && !is_numeric($name))
		{

			//save to database
			$user_id = random_num(20);
			$query = "insert into contacts(user_id,name,phNo,email) values ('$user_id','$name','$phNo','$email')";

			mysqli_query($con, $query);

			header("Location: my contacts.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
</head>
<body>

	<style type="text/css">
	
	#text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 35%;
	}

	#button{

		padding: 10px;
		width: 38%;
		color: white;
		background-color:blue;
		border: none;
	}

	#box{

		background-color: white;
		margin: auto;
		width: 950px;
		padding: 10px;
		boxsizing:border-box;
	}
	div.relative{
		position:relative;
		left:10px;
		top:2px;
	}
	div.a {
  position: relative;
  left:30px;
  right:20px;
  top:20px;
  ;
 
  
  
}
div.b{
  position: relative;
  left:150px;
 
  
  
}

	</style>

	<div id="box">
		
		<form method="post">
			<div class="relative" style="font-size: 30px;margin: 10px;color: solid black;">Contacts Form and Contacts List Page</div>
		
			
			<div class="a" > Name</div>

			<div class="a" > <input id="text" type="text" name="name"><br><br> </div>
			
			<div class="a"> Ph No</div>
			
			
			<div class="a" > <input id="text" type="phNo" name="phNo"><br><br> </div>
			<div  class="a" > Email</div>
			<div class="a"> <input id="text" type="email" name="email"><br><br></div>

			<div class="a"> <input id="button" type="submit" value="Save"><br><br></div>
			
			
			
			
			
			
			

			
		</form>
	</div>
</body>
</html>
